﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 MFCCACLUI.rc 使用
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MFC_CACL_UI_DIALOG          102
#define IDR_MAINFRAME                   128
#define IDC_EDIT_RESULT                 1000
#define IDC_SIN_CACL                    1001
#define IDC_COS_CACL                    1002
#define IDC_ARCSIN_CACL                 1003
#define IDC_ARCTAN_CACL                 1004
#define IDC_BUTTON5                     1005
#define IDC_BUTTON_1                    1005
#define IDC_BUTTON6                     1006
#define IDC_BUTTON_2                    1006
#define IDC_BUTTON7                     1007
#define IDC_BUTTON_3                    1007
#define IDC_BUTTON8                     1009
#define IDC_BUTTON_4                    1009
#define IDC_BUTTON9                     1010
#define IDC_BUTTON_5                    1010
#define IDC_BUTTON10                    1011
#define IDC_BUTTON_6                    1011
#define IDC_BUTTON11                    1012
#define IDC_BUTTON_7                    1012
#define IDC_BUTTON12                    1013
#define IDC_BUTTON_8                    1013
#define IDC_BUTTON13                    1014
#define IDC_BUTTON_9                    1014
#define IDC_BUTTON_MYDEL                1015
#define IDC_BUTTON15                    1016
#define IDC_BUTTON_0                    1016
#define IDC_BUTTON16                    1017
#define IDC_BUTTON_RESULT               1017
#define IDC_BUTTON_D                    1018

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
